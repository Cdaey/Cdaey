#include<stdio.h>
#include<dirent.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<string.h>

int main(int argc, char *argv[])
{
	DIR *dp;
	struct dirent *dir;
	char *ptr;
	struct stat buf;
	int flag = 0;
	int i,j;
	
	if(argc == 2) // 옵션을 받음
	{
			if(argv[1][0]=='-')
				switch(argv[1][1])
				{
					case 'a':  //ls -a 옵션
						flag=1;
						break;
				}
	}

	if((dp = opendir(".")) == NULL)  //현재 폴더로 디렉토리 오픈
	{
		fprintf(stderr,"directory open error\n");
		exit(0);
	}
	
	while((dir=readdir(dp)) != NULL)
	{
		if(dir->d_ino == 0)  //파일이 존재 하지않으면 넘어감
			continue;
		
		if(flag == 0)  //.으로 시작하는 파일, 폴더 생략
		{	
			if(strncmp(dir->d_name, ".", 1) == 0)
				continue;
		}

		printf("%s\n", dir->d_name);
	}
	closedir(dp);

	return 0;
}
