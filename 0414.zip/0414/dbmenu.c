#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

void print_menu(void);
void check_menu(int num, char filename[]);
void result(int num,char filename[]);

int main(void)
{	
	system("clear");
	print_menu();
	return 0;
}

void print_menu(void)
{	
	int num;
	char filename[15];
	printf("\n\n");
	printf("1. db 생성\n");
	printf("2. db 검색\n");
	printf("3. db 갱신\n");
	printf("0. 종료\n\n");
	printf("사용법(명령번호 파일명) : ");
	scanf("%d",&num);
	if(num==0) 
	{
		printf("\n종료합니다....\n");
		exit(0);
	}
	scanf("%s",filename);
	check_menu(num,filename);
}

void check_menu(int num,char filename[])
{
	if(num<0||num>3)
	{
		printf("\n\n잘못된 명령 번호 입니다.\n정확하게 재입력 해주세요..\n\n");
		print_menu();
	}
	else
		result(num,filename);
}	

void result(int num, char filename[])
{
		switch(num)
		{
			case 1 : execl("./dbcreate","dbcreate",filename,NULL);
				break;
			case 2 : execl("./dbquery","dbquery",filename,NULL);
				break;
			case 3 : execl("./dbupdate","dbupdate",filename,NULL);
				break;
			default : break;
		}
}



