<?
echo "Hello PHP world";
?>
